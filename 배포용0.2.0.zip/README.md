# 설치할 라이브러리
npm install 
-> 모듈 설치

npm install express mysql2 dotenv http-status-codes jsonwebtoken helmet
-> 사용자용 라이브러리

npm install --save-dev @babel/cli @babel/core @babel/preset-env eslint prettier
npm install lint-staged --save-dev
-> 개발자용 라이브러리
